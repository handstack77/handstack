export function stringify(value: any): string;
export function isDefined(variable: any): boolean;
export function isUndefined(variable: any): boolean;
export function isEmpty(variable: any): boolean;
export function isRegExp(variable: any): boolean;
