export function log(...args: any[]): void;
export function warn(...args: any[]): void;
export function info(...args: any[]): void;
export function error(...args: any[]): void;
