export function toSingleLine(strings: string[], ...expressions: string[]): string;
