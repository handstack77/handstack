export function getNormalizedDate(dateString: string): Date;
