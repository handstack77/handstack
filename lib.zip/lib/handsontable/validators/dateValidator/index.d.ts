export { VALIDATOR_TYPE, dateValidator } from './dateValidator';
