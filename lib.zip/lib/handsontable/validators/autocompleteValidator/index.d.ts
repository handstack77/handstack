export { VALIDATOR_TYPE, autocompleteValidator } from './autocompleteValidator';
