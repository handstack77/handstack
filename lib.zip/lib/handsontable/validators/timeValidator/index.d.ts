export { VALIDATOR_TYPE, timeValidator } from './timeValidator';
