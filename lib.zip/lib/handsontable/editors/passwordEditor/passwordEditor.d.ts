import Core from '../../core';
import { TextEditor } from '../textEditor';

export const EDITOR_TYPE: 'password';
export class PasswordEditor extends TextEditor {
  constructor(instance: Core);
}
