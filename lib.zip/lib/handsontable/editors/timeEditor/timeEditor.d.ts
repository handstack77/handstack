import Core from '../../core';
import { TextEditor } from '../textEditor';

export const EDITOR_TYPE: 'time';
export class TimeEditor extends TextEditor {
  constructor(instance: Core);
}
