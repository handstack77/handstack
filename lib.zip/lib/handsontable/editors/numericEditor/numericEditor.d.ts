import Core from '../../core';
import { TextEditor } from '../textEditor';

export const EDITOR_TYPE: 'numeric';
export class NumericEditor extends TextEditor {
  constructor(instance: Core);
}
