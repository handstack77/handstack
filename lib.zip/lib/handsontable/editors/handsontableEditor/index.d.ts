export { EDITOR_TYPE, HandsontableEditor } from './handsontableEditor';
