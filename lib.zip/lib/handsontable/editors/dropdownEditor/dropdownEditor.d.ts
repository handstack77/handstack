import Core from '../../core';
import { AutocompleteEditor } from '../autocompleteEditor';

export const EDITOR_TYPE: 'dropdown';
export class DropdownEditor extends AutocompleteEditor {
  constructor(instance: Core);
}
