import Handsontable from './index';

export * from './index';
export default Handsontable;
