export default dictionary;
declare const dictionary: {
  [x: string]: string | string[];
  languageCode: 'nl-NL';
};
