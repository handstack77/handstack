export * from './textType';
