export { RENDERER_TYPE, handsontableRenderer } from './handsontableRenderer';
