export { RENDERER_TYPE, passwordRenderer } from './passwordRenderer';
