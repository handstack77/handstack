import { baseRenderer } from './baseRenderer';

export type BaseRenderer = typeof baseRenderer;
