export { RENDERER_TYPE, selectRenderer } from './selectRenderer';
