export { RENDERER_TYPE, autocompleteRenderer } from './autocompleteRenderer';
