export { RENDERER_TYPE, textRenderer } from './textRenderer';
