export { ShortcutManager } from './manager';
