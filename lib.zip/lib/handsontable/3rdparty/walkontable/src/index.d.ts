export type OverlayType = 'top' | 'bottom' | 'left' | 'top_left_corner' | 'bottom_left_corner';
