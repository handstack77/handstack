import Core from '../../core';
import { ColumnSorting } from '../columnSorting';

export * from '../columnSorting';

export class MultiColumnSorting extends ColumnSorting {
  constructor(hotInstance: Core);
}
