export interface SelectionController {
  row: boolean;
  column: boolean;
  cell: boolean;
}
