using System.Collections.Generic;
using System.Threading.Tasks;

using HandStack.Web;
using HandStack.Web.ApiClient;
using HandStack.Web.Entity;

using createmodule.Entity;

using Newtonsoft.Json.Linq;

using Serilog;

namespace createmodule.Extensions
{
    public class ModuleApiClient
    {
        private ILogger logger { get; }
        private readonly TransactionClient transactionClient;

        public ModuleApiClient(ILogger logger, TransactionClient transactionClient)
        {
            this.logger = logger;
            this.transactionClient = transactionClient;
        }

        public async Task<Dictionary<string, JToken>> TransactionDirect(string businessID, string transactionID, string functionID, params List<ServiceParameter>[] serviceParameters)
        {
            Dictionary<string, JToken> result;

            TransactionClientObject transactionObject = new TransactionClientObject();
            transactionObject.SystemID = TransactionConfig.Transaction.SystemID;
            transactionObject.ProgramID = GlobalConfiguration.ApplicationID;
            transactionObject.BusinessID = businessID;
            transactionObject.TransactionID = transactionID;
            transactionObject.FunctionID = functionID;

            if (serviceParameters == null || serviceParameters.Length == 0)
            {
                transactionObject.Inputs.Add(new List<ServiceParameter>());
            }
            else
            {
                foreach (var serviceParameter in serviceParameters)
                {
                    List<ServiceParameter> inputs = new List<ServiceParameter>();
                    foreach (var item in serviceParameter)
                    {
                        inputs.Add(item);
                    }
                    transactionObject.Inputs.Add(inputs);
                }
            }

            result = await transactionClient.TransactionDirect(ModuleConfiguration.BusinessServerUrl, transactionObject);

            return result;
        }
    }
}
