using Microsoft.AspNetCore.Mvc.RazorPages;

namespace createmodule.Areas.createmodule.Pages
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
